<?php include '../../config/constants.php'; ?>
<!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http: //www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>
    <?php include 'meta.php' ?>
    <title><?php echo $appName ?> | Admin Portal</title>
</head>

<body>
    <?php include 'header.php' ?>
    <?php include 'side-bar.php' ?>


    <main id="page-content" class="animated fadeIn">
        <script>
        _getActivePage({
            page: 'dashboard',
            divid: 'dashboard'
        });
        </script>

    </main>
</body>
<?php include 'bottom-scripts.php'?>

</html>