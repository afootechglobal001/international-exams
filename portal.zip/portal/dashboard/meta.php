<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="ROBOTS" content="ALL">
<meta name="Engine" content="all">
<meta name="distribution" content="global">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="<?php echo $websiteUrl?>/all-images/images/icon.png" rel="shortcut icon" type="image-png" />
<link href="<?php echo $websiteUrl?>/style/icons-1.11.3/font/bootstrap-icons.css" type="text/css" rel="stylesheet">
<link href="<?php echo $websiteUrl?>/style/animate.css" type="text/css" rel="stylesheet" media="all">
<link href="<?php echo $websiteUrl?>/style/aos.css" type="text/css" rel="stylesheet" />
<link href="<?php echo $websiteUrl?>/style/paramount.css?v=<?php echo $codeVersion?>" type="text/css"
    rel="stylesheet" />
<link href="<?php echo $websiteUrl?>/style/tablePagenator.css?v=<?php echo $codeVersion?>" type="text/css"
    rel="stylesheet" />
<link href="<?php echo $websiteUrl?>/portal/dashboard/style/main-style.css?v=<?php echo $codeVersion?>" type="text/css"
    rel="stylesheet" />
<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

<script src="<?php echo $websiteUrl?>/js/jquery-v3.6.1.min.js"></script>
<script>
let userLoginData = JSON.parse(sessionStorage.getItem("userLoginData"));
const loginUserId = userLoginData.userId;
const loginAccessKey = userLoginData.accessKey;
const loginCountryData = userLoginData.countryData;
</script>

<script src="<?php echo $websiteUrl?>/js/textfield-selectfield.js?v=<?php echo $codeVersion?>"></script>
<script src="<?php echo $websiteUrl?>/js/aos.js"></script>
<script src="<?php echo $websiteUrl?>/js/paramount.js?v=<?php echo $codeVersion?>"></script>
<script src="<?php echo $websiteUrl?>/js/tablePagenator.js?v=<?php echo $codeVersion?>"></script>
<script src="<?php echo $websiteUrl?>/js/helper.js"></script>
<script src="https://js.paystack.co/v1/inline.js"></script>


<script src="<?php echo $websiteUrl?>/portal/dashboard/js/usePortal.js?v=<?php echo $codeVersion?>"></script>
<script src="<?php echo $websiteUrl?>/portal/dashboard/js/usePayment.js?v=<?php echo $codeVersion?>"></script>
<script src="<?php echo $websiteUrl?>/portal/dashboard/js/useExams.js?v=<?php echo $codeVersion?>"></script>
<script src="<?php echo $websiteUrl?>/portal/dashboard/js/useEbook.js?v=<?php echo $codeVersion?>"></script>